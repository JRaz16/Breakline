class_name PQueue
extends Object

var precedes:Callable
var heap:Array

func _init(f:Callable):
	precedes = f

func is_empty() -> bool:
	return heap.is_empty()

func front() -> Variant:
	return heap[0]

func enqueue(x):
	heap.push_back(null)
	increase_key(heap.size() - 1, x)

func dequeue() -> Variant:
	if heap.size() < 1:
		return null # error “heap underflow”
	var extremum = heap[0]
	heap[0] = heap.back()
	heap.pop_back()
	heapify(0)
	return extremum

func increase_key(i:int, x:Variant):
	heap[i] = x
	var j = parent(i)
	while i > 0 and precedes.call(heap[i], heap[j]):
		var tmp = heap[i]
		heap[i] = heap[j]
		heap[j] = tmp
		i = j
		j = parent(i)

func heapify(i:int):
	var l = left(i)
	var r = right(i)
	var extremum:int
	if l < heap.size() and precedes.call(heap[l], heap[i]):
		extremum = l
	else:
		extremum = i
	if r < heap.size() and precedes.call(heap[r], heap[extremum]):
		extremum = r
	if extremum != i:
		var tmp = heap[i]
		heap[i] = heap[extremum]
		heap[extremum] = tmp
		heapify(extremum)

func left(i:int) -> int:
	return 2 * (i+1) - 1

func parent(i:int) -> int:
	return floor((i - 1) / 2)

func right(i:int) -> int:
	return 2 * (i+1)
